import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.morse.app"
    compileSdk = 34
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    defaultConfig {
        applicationId = "com.morse.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }

// Descarga Tailwind al compilar para que la app funcione sin internet
val twFile = file("src/main/assets/tailwind.js")
tasks.register("downloadTailwind") {
    doLast {
        if (!twFile.exists() || twFile.length() < 100_000) {
            URL("https://cdn.tailwindcss.com/3.4.17").openStream().use { i -> twFile.outputStream().use { o -> i.copyTo(o) } }
        }
        if (twFile.length() < 100_000) throw GradleException("No se pudo descargar tailwind.js")
    }
}
tasks.named("preBuild") { dependsOn("downloadTailwind") }
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn("downloadTailwind") }
