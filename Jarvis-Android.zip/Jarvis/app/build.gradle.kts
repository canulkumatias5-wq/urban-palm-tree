plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.jarvis.app"
    compileSdk = 34
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    defaultConfig {
        applicationId = "com.jarvis.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
}

// Descarga el modelo de voz en español (sin internet después) al compilar
val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"
val modelDir = file("src/main/assets/model-es")
tasks.register("downloadModel") {
    doLast {
        if (!File(modelDir, "am").exists()) {
            modelDir.mkdirs()
            java.net.URL(modelUrl).openStream().use { raw ->
                java.util.zip.ZipInputStream(raw).use { zip ->
                    var e = zip.nextEntry
                    while (e != null) {
                        val rel = e.name.substringAfter("/", "")
                        if (rel.isNotEmpty()) {
                            val f = File(modelDir, rel)
                            if (e.isDirectory) f.mkdirs() else { f.parentFile.mkdirs(); f.outputStream().use { zip.copyTo(it) } }
                        }
                        e = zip.nextEntry
                    }
                }
            }
            File(modelDir, "uuid").writeText("atlas-model-1")
        }
    }
}
tasks.named("preBuild") { dependsOn("downloadModel") }
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn("downloadModel") }
