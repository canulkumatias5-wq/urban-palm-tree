package com.jarvis.app

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.TextView
import java.text.Normalizer
import java.util.Locale

fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").replace(Regex("[¿?¡!.,]"), "").trim()

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private val h = Handler(Looper.getMainLooper())
    private var orb: OrbView? = null
    private var calib: View? = null
    private var recognizer: SpeechRecognizer? = null
    private var active = false
    private var speaking = false
    private var endAfterSpeech = false
    private var running = false
    private var misses = 0
    private val wake = listOf("oye jarvis", "jarvis", "yarvis", "jarbis", "yarbis", "ayudame")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis activo")
            .setContentText("Di «Jarvis» o «ayúdame»").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        tts.language = Locale("es", "ES")
        tts.setPitch(0.8f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { h.post { speaking = true; orb?.speaking = true } }
            override fun onDone(id: String?) {
                h.post {
                    speaking = false; orb?.speaking = false
                    if (endAfterSpeech) { endAfterSpeech = false; active = false; hideOrb() }
                    listen()
                }
            }
            @Deprecated("deprecated") override fun onError(id: String?) { onDone(id) }
        })
        running = true
        listen()
    }

    private fun say(text: String, end: Boolean) {
        endAfterSpeech = end
        speaking = true
        recognizer?.cancel()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        if (!running || speaking) return
        recognizer?.destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t == null) retry(300) else onHeard(t)
            }
            override fun onError(e: Int) {
                if (active && ++misses > 3) { active = false; misses = 0; hideOrb() }
                retry(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 300)
            }
            override fun onRmsChanged(v: Float) { orb?.level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES"))
    }

    private fun retry(ms: Long) { h.postDelayed({ listen() }, ms) }

    private fun onHeard(raw: String) {
        misses = 0
        val c = norm(raw)
        val hasWake = wake.any { c.contains(it) }
        if (!active && !hasWake) { listen(); return }
        if (!active) { active = true; showOrb() }
        var cmd = c
        wake.forEach { cmd = cmd.replace(it, "") }
        cmd = cmd.trim()
        if (cmd.isEmpty()) { say("A sus órdenes, señor", false); return }
        say(run(cmd, raw), true)
    }

    // ---------------- comandos ----------------
    private fun run(c: String, raw: String): String {
        val acc = JarvisAccessibility.inst
        fun needAcc(): String? = if (acc == null) "Active primero la accesibilidad de Jarvis, señor" else null

        if (c in listOf("para", "detente", "alto", "basta", "ya", "para ya")) { acc?.stopHold(); return "Okey, señor" }
        if (c.contains("apagate") || c.contains("desactivate")) { h.postDelayed({ stopSelf() }, 2500); return "Hasta luego, señor" }

        Regex("(?:configura|guarda|registra)\\s+(?:el\\s+)?boton\\s+(.+)").find(c)?.let {
            showCalibration(it.groupValues[1].trim()); return "Toque en la pantalla donde está el botón"
        }

        Regex("(?:mandale|manda|envia|enviale|escribe|escribele)\\s+(?:un\\s+)?(?:mensaje|whatsapp|wasap)?\\s*(?:a|al)\\s+(.+?)\\s*(?:por\\s+(?:whatsapp|wasap|guasap|whats))?\\s*(?:que\\s+(?:diga|dice|ponga)|diciendo)\\s+(.+)").find(c)?.let { m ->
            val name = m.groupValues[1].removePrefix("mi ").trim()
            val msg = Regex("(?:que diga|que dice|que ponga|diciendo)\\s+(.+)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1) ?: m.groupValues[2]
            val n = findNumber(name) ?: return "No encuentro a $name en sus contactos"
            val uri = Uri.parse("https://wa.me/${n.filter { it.isDigit() }}?text=${Uri.encode(msg)}")
            try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).setPackage("com.whatsapp")) }
            catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            h.postDelayed({ acc?.clickAny("enviar", "send") }, 3500)
            return "Listo, señor"
        }

        Regex("llama(?:r)?\\s+(?:a|al)\\s+(.+)").find(c)?.let { m ->
            val name = m.groupValues[1].removePrefix("mi ").trim()
            val n = findNumber(name) ?: return "No encuentro a $name en sus contactos"
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return "Falta el permiso de llamadas"
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Llamando a $name"
        }

        if (c.contains("volumen")) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = c.contains("sube") || c.contains("mas") || c.contains("aumenta")
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return "Listo, señor"
        }

        Regex("^(?:abre|abrir|ejecuta|inicia)\\s+(.+)").find(c)?.let { return openApp(it.groupValues[1]) }
        Regex("^(?:busca|buscar)\\s+(.+)").find(c)?.let {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1]))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Buscando, señor"
        }

        // botones guardados (juegos)
        val verbs = listOf("manten", "aprieta", "presiona", "pulsa", "toca")
        if (verbs.any { c.contains(it) }) {
            val key = prefs.all.keys.filter { it.startsWith("pos_") }.map { it.removePrefix("pos_") }.firstOrNull { c.contains(it) }
                ?: return "No tengo ese botón guardado. Diga: configura botón, y el nombre"
            needAcc()?.let { return it }
            val (x, y) = prefs.getString("pos_$key", "0,0")!!.split(",").map { it.toFloat() }
            if (c.contains("toca")) acc!!.tap(x, y) else acc!!.startHold(x, y)
            return "Okey, señor"
        }

        // gestos
        val gestures = listOf(
            listOf("desliza", "baja", "siguiente", "proximo") to "up",
            listOf("sube", "anterior") to "down",
            listOf("izquierda") to "left",
            listOf("derecha") to "right")
        gestures.firstOrNull { (words, _) -> words.any { c.contains(it) } }?.let { (_, dir) ->
            needAcc()?.let { return it }
            acc!!.swipe(dir); return "Listo, señor"
        }

        val globals = listOf("atras" to AccessibilityServiceGlobal.BACK, "inicio" to AccessibilityServiceGlobal.HOME,
            "recientes" to AccessibilityServiceGlobal.RECENTS, "notificaciones" to AccessibilityServiceGlobal.NOTIFICATIONS,
            "captura" to AccessibilityServiceGlobal.SCREENSHOT, "bloquea" to AccessibilityServiceGlobal.LOCK,
            "apaga la pantalla" to AccessibilityServiceGlobal.LOCK)
        globals.firstOrNull { c.contains(it.first) }?.let {
            needAcc()?.let { m -> return m }
            acc!!.performGlobalAction(it.second); return "Listo, señor"
        }

        if (c.contains("que hora")) return "Son las " + java.text.SimpleDateFormat("H 'y' mm", Locale("es")).format(java.util.Date())
        if (c.contains("quien eres")) return "Soy Jarvis, su asistente"
        if (c.contains("gracias")) return "Es un placer, señor"
        return "No he entendido, señor"
    }

    private object AccessibilityServiceGlobal {
        const val BACK = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
        const val HOME = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
        const val RECENTS = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
        const val NOTIFICATIONS = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
        const val SCREENSHOT = 9  // GLOBAL_ACTION_TAKE_SCREENSHOT (Android 9+)
        const val LOCK = 8        // GLOBAL_ACTION_LOCK_SCREEN (Android 9+)
    }

    private fun openApp(spoken: String): String {
        val alias = mapOf("wasap" to "whatsapp", "guasap" to "whatsapp", "whats" to "whatsapp", "insta" to "instagram", "yutub" to "youtube")
        val t = (alias[spoken.trim()] ?: spoken).replace(" ", "")
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val labelOf = { a: android.content.pm.ResolveInfo -> norm(a.loadLabel(pm).toString()).replace(" ", "") }
        val app = apps.firstOrNull { labelOf(it) == t } ?: apps.firstOrNull { labelOf(it).contains(t) } ?: return "No encuentro la aplicación $spoken"
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "No puedo abrirla"
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Abriendo ${app.loadLabel(pm)}"
    }

    private fun findNumber(name: String): String? {
        val digits = name.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 6) return digits
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val t = norm(name)
        val list = mutableListOf<Pair<String, String>>()
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) list.add(norm(c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return (list.firstOrNull { it.first == t } ?: list.firstOrNull { it.first.contains(t) })?.second
    }

    // ---------------- overlay ----------------
    private fun showOrb() {
        if (orb != null || !Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density
        val s = (240 * d).toInt()
        val lp = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (80 * d).toInt() }
        orb = OrbView(this).also { wm.addView(it, lp) }
    }

    private fun hideOrb() { orb?.let { try { wm.removeView(it) } catch (e: Exception) {} }; orb = null }

    private fun showCalibration(name: String) {
        if (!Settings.canDrawOverlays(this)) return
        val key = name.lowercase()
        val tv = TextView(this).apply {
            text = "Toque donde está el botón «$key»"; setTextColor(Color.WHITE); textSize = 20f
            gravity = Gravity.CENTER; setBackgroundColor(Color.argb(150, 0, 0, 0))
        }
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                prefs.edit().putString("pos_$key", "${e.rawX},${e.rawY}").apply()
                try { wm.removeView(tv) } catch (x: Exception) {}
                calib = null
                say("Guardado, señor", true)
            }
            true
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        calib = tv
        wm.addView(tv, lp)
    }

    override fun onDestroy() {
        running = false
        JarvisAccessibility.inst?.stopHold()
        recognizer?.destroy()
        tts.shutdown()
        hideOrb()
        calib?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        super.onDestroy()
    }
}
