package com.jarvis.app

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Locale
import kotlin.random.Random

fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").replace(Regex("[¿?¡!.,]"), "").trim()

class JarvisService : Service(), TextToSpeech.OnInitListener {
    companion object { @Volatile var alive = false }

    private lateinit var wm: WindowManager
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private val h = Handler(Looper.getMainLooper())
    private var orb: OrbView? = null
    private var calib: View? = null
    private var speech: SpeechService? = null
    private var model: Model? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var active = false
    private var speaking = false
    private var endAfterSpeech = false
    private var pitch = 0.85f
    private var warnedOverlay = false
    private val name by lazy { norm(getString(R.string.app_name)) }
    private val SESSION_MS = 25_000L
    private val AI_MARK = "\u0000AI"
    private val sessionTimer = Runnable { endSession() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        alive = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Atlas", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Atlas activo")
            .setContentText("Di «${getString(R.string.app_name)}» o «ayúdame»").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "atlas:mic").apply { acquire() }
        tts = TextToSpeech(this, this)
    }

    // ---------------- voz (TTS) ----------------
    override fun onInit(status: Int) {
        tts.language = Locale("es", "ES")
        pitch = prefs.getFloat("pitch", 0.85f)
        tts.setPitch(pitch)
        tts.setSpeechRate(1.05f)
        tts.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        applyVoice()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { finishSpeaking() } }
            @Deprecated("deprecated") override fun onError(id: String?) { h.post { finishSpeaking() } }
        })
        loadModel()
    }

    private fun spanishVoices(): List<Voice> {
        val all = (tts.voices ?: emptySet()).filter { it.locale.language == "es" }
        val offline = all.filter { !it.isNetworkConnectionRequired }
        return (if (offline.isNotEmpty()) offline else all).sortedWith(compareBy({ it.isNetworkConnectionRequired }, { -it.quality }, { it.name }))
    }

    private fun applyVoice() {
        val vs = spanishVoices()
        if (vs.isEmpty()) return
        val saved = prefs.getString("voice", null)
        tts.voice = vs.firstOrNull { it.name == saved }
            ?: vs.firstOrNull { it.name.contains("male", true) && !it.name.contains("female", true) }
            ?: vs.firstOrNull { it.name.contains("-eed-") || it.name.contains("-esd-") || it.name.contains("-eef-") }
            ?: vs.first()
    }

    private fun nextVoice() {
        val vs = spanishVoices()
        if (vs.isEmpty()) return
        val i = vs.indexOfFirst { it.name == tts.voice?.name }
        val v = vs[(i + 1) % vs.size]
        tts.voice = v
        prefs.edit().putString("voice", v.name).apply()
    }

    private fun sir() = if (Random.nextInt(100) < 15) ", señor" else ""

    private fun say(text: String, end: Boolean) {
        endAfterSpeech = end
        speaking = true
        speech?.setPause(true)
        h.removeCallbacks(sessionTimer)
        orb?.speaking = true
        tts.speak(text.replace(", señor", sir()), TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun finishSpeaking() {
        orb?.speaking = false
        h.postDelayed({
            speaking = false
            speech?.setPause(false)
            if (endAfterSpeech) { endAfterSpeech = false; endSession() } else if (active) touchSession()
        }, 350)
    }

    // ---------------- escucha sin internet (Vosk) ----------------
    private fun copyAssets(src: String, dst: File) {
        val list = assets.list(src) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            try { assets.open(src).use { i -> dst.outputStream().use { o -> i.copyTo(o) } } } catch (e: Exception) {}
        } else {
            dst.mkdirs()
            for (n in list) copyAssets("$src/$n", File(dst, n))
        }
    }

    private fun loadModel() {
        Thread {
            try {
                val dst = File(filesDir, "model-es")
                val marker = File(dst, "uuid")
                val want = assets.open("model-es/uuid").bufferedReader().readText()
                if (!marker.exists() || marker.readText() != want) { dst.deleteRecursively(); copyAssets("model-es", dst) }
                val m = Model(dst.absolutePath)
                val s = SpeechService(Recognizer(m, 16000.0f), 16000.0f)
                h.post { model = m; speech = s; s.startListening(listener); say("Atlas activo", false) }
            } catch (e: Throwable) {
                h.post { Toast.makeText(this, "Error cargando la voz: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            val t = try { JSONObject(hypothesis ?: return).optString("partial") } catch (e: Exception) { return }
            if (t.isBlank() || speaking) return
            orb?.level = 0.8f
            if (!active && isWake(norm(t))) activate() else if (active) touchSession()
        }
        override fun onResult(hypothesis: String?) {
            val t = try { norm(JSONObject(hypothesis ?: return).optString("text")) } catch (e: Exception) { return }
            if (t.isNotBlank()) handleUtterance(t)
        }
        override fun onFinalResult(hypothesis: String?) {}
        override fun onError(exception: Exception?) {}
        override fun onTimeout() {}
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun wakeToken(t: String) = t == name || (name.length >= 6 && lev(t, name) <= 1) || (t.length >= 6 && lev(t, "ayudame") <= 1)
    private fun isWake(n: String) = n.split(" ").any { wakeToken(it) }
    private fun stripWake(c: String) = c.split(" ").filter { it.isNotEmpty() && !wakeToken(it) && it != "oye" }.joinToString(" ").trim()

    private fun activate() { active = true; showOrb(); touchSession() }
    private fun touchSession() { h.removeCallbacks(sessionTimer); h.postDelayed(sessionTimer, SESSION_MS) }
    private fun endSession() { active = false; h.removeCallbacks(sessionTimer); hideOrb() }

    private fun handleUtterance(c: String) {
        if (speaking) return
        val hit = isWake(c)
        if (!active && !hit) return
        if (!active) activate() else touchSession()
        val cmd = stripWake(c)
        if (cmd.length < 2) { if (hit) say("A sus órdenes" + sir(), false); return }
        if (Regex("^(gracias|adios|hasta luego|eso es todo|nada mas|ya esta)").containsMatchIn(cmd)) { say("Hasta luego", true); return }
        val reply = run(cmd, cmd)
        when {
            reply == AI_MARK -> askAi(cmd)
            reply == "No he entendido, señor" -> if (hit) askAi(cmd)
            else -> say(reply, false)
        }
    }

    // ---------------- comandos ----------------
    private fun run(c: String, raw: String): String {
        val acc = JarvisAccessibility.inst
        fun needAcc(): String? = if (acc == null) "Active primero la accesibilidad de Atlas" else null

        if (c in listOf("para", "detente", "alto", "basta", "ya", "para ya")) { acc?.stopHold(); return "Okey" }
        if (c.contains("apagate") || c.contains("desactivate")) { h.postDelayed({ stopSelf() }, 2500); return "Hasta luego" }

        if ((c.contains("cambia") && c.contains("voz")) || c.contains("otra voz")) { nextVoice(); return "¿Le gusta esta voz?" }
        if (c.contains("voz") && (c.contains("grave") || c.contains("aguda"))) {
            pitch = (pitch + if (c.contains("grave")) -0.1f else 0.1f).coerceIn(0.5f, 1.5f)
            tts.setPitch(pitch); prefs.edit().putFloat("pitch", pitch).apply()
            return "¿Así está mejor?"
        }

        Regex("(?:configura|guarda|registra)\\s+(?:el\\s+)?boton\\s+(.+)").find(c)?.let {
            showCalibration(it.groupValues[1].trim()); return "Toque en la pantalla donde está el botón"
        }

        Regex("(?:mandale|manda|envia|enviale|escribe|escribele)\\s+(?:un\\s+)?(?:mensaje|whatsapp|wasap)?\\s*(?:a|al)\\s+(.+?)\\s*(?:por\\s+(?:whatsapp|wasap|guasap|whats))?\\s*(?:que\\s+(?:diga|dice|ponga)|diciendo)\\s+(.+)").find(c)?.let { m ->
            val who = m.groupValues[1].removePrefix("mi ").trim()
            val msg = m.groupValues[2]
            val n = findNumber(who) ?: return "No encuentro a $who en sus contactos"
            val uri = Uri.parse("https://wa.me/${n.filter { it.isDigit() }}?text=${Uri.encode(msg)}")
            try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).setPackage("com.whatsapp")) }
            catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            h.postDelayed({ acc?.clickAny("enviar", "send") }, 3500)
            return "Listo"
        }

        Regex("llama(?:r)?\\s+(?:a|al)\\s+(.+)").find(c)?.let { m ->
            val who = m.groupValues[1].removePrefix("mi ").trim()
            val n = findNumber(who) ?: return "No encuentro a $who en sus contactos"
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return "Falta el permiso de llamadas"
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Llamando a $who"
        }

        if (c.contains("volumen")) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = c.contains("sube") || c.contains("mas") || c.contains("aumenta")
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return "Listo"
        }

        Regex("^(?:abre|abrir|ejecuta|inicia)\\s+(.+)").find(c)?.let { return openApp(it.groupValues[1]) }
        Regex("^(?:busca|buscar)\\s+(.+)").find(c)?.let {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1]))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Buscando"
        }

        if (Regex("^(dime|quien|que|cual|cuales|cuanto|cuanta|cuantos|cuantas|como|cuando|donde|por que|explica|explicame|calcula|resuelve|raiz|define|traduce|cuenta)\\b").containsMatchIn(c)
            && !c.contains("que hora") && !c.contains("quien eres") && !c.contains("como estas") && !c.contains("que tal")) return AI_MARK

        val verbs = listOf("manten", "aprieta", "presiona", "pulsa", "toca")
        if (verbs.any { c.contains(it) }) {
            val key = prefs.all.keys.filter { it.startsWith("pos_") }.map { it.removePrefix("pos_") }.firstOrNull { c.contains(it) }
                ?: return "No tengo ese botón guardado. Diga: configura botón, y el nombre"
            needAcc()?.let { return it }
            val (x, y) = prefs.getString("pos_$key", "0,0")!!.split(",").map { it.toFloat() }
            if (c.contains("toca")) acc!!.tap(x, y) else acc!!.startHold(x, y)
            return "Okey"
        }

        val gestures = listOf(
            listOf("desliza", "baja", "siguiente", "proximo") to "up",
            listOf("sube", "anterior") to "down",
            listOf("izquierda") to "left",
            listOf("derecha") to "right")
        gestures.firstOrNull { (words, _) -> words.any { c.contains(it) } }?.let { (_, dir) ->
            needAcc()?.let { return it }
            acc!!.swipe(dir); return "Listo"
        }

        val globals = listOf("atras" to AccessibilityServiceGlobal.BACK, "inicio" to AccessibilityServiceGlobal.HOME,
            "recientes" to AccessibilityServiceGlobal.RECENTS, "notificaciones" to AccessibilityServiceGlobal.NOTIFICATIONS,
            "captura" to AccessibilityServiceGlobal.SCREENSHOT, "bloquea" to AccessibilityServiceGlobal.LOCK,
            "apaga la pantalla" to AccessibilityServiceGlobal.LOCK)
        globals.firstOrNull { c.contains(it.first) }?.let {
            needAcc()?.let { m -> return m }
            acc!!.performGlobalAction(it.second); return "Listo"
        }

        if (c.contains("que hora")) return "Son las " + java.text.SimpleDateFormat("H 'y' mm", Locale("es")).format(java.util.Date())
        if (c.contains("quien eres")) return "Soy Atlas, su asistente"
        if (c.contains("como estas") || c.contains("que tal")) return "Todo en orden"
        if (c.contains("gracias")) return "Es un placer"
        return "No he entendido, señor"
    }

    private object AccessibilityServiceGlobal {
        const val BACK = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
        const val HOME = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
        const val RECENTS = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
        const val NOTIFICATIONS = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
        const val SCREENSHOT = 9
        const val LOCK = 8
    }

    private fun askAi(q: String) {
        val key = prefs.getString("gemini_key", "")?.trim().orEmpty()
        if (key.isEmpty()) { say("No he entendido. Para responder dudas, pegue la clave de Gemini en la aplicación.", false); return }
        speaking = true
        Thread {
            var answer: String? = null
            var code = 0
            for (m in listOf("gemini-flash-latest", "gemini-2.5-flash", "gemini-flash-lite-latest")) {
                try {
                    val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.setRequestProperty("x-goog-api-key", key)
                    conn.connectTimeout = 10000; conn.readTimeout = 25000; conn.doOutput = true
                    val sys = "Eres Atlas, un asistente de voz. Responde en español, claro y breve (máximo 3 frases), sin markdown ni símbolos raros. Casi nunca digas la palabra señor."
                    val body = JSONObject()
                        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                        .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q)))))
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                    code = conn.responseCode
                    if (code == 200) {
                        val txt = conn.inputStream.bufferedReader().readText()
                        answer = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                        break
                    }
                } catch (e: Exception) {}
            }
            val msg = answer?.replace(Regex("[*#_`]"), "")?.trim()
                ?: if (code == 429) "Se agotó el límite gratuito por ahora."
                else if (code == 400 || code == 403) "La clave de Gemini no parece válida."
                else "No pude consultar la inteligencia artificial. Sin internet no puedo responder dudas."
            h.post { say(msg, false) }
        }.start()
    }

    private fun openApp(spoken: String): String {
        val alias = mapOf("wasap" to "whatsapp", "guasap" to "whatsapp", "whats" to "whatsapp", "insta" to "instagram", "yutub" to "youtube", "tik tok" to "tiktok")
        val t = (alias[spoken.trim()] ?: spoken).replace(" ", "")
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val labelOf = { a: android.content.pm.ResolveInfo -> norm(a.loadLabel(pm).toString()).replace(" ", "") }
        val app = apps.firstOrNull { labelOf(it) == t } ?: apps.firstOrNull { labelOf(it).contains(t) } ?: return "No encuentro la aplicación $spoken"
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "No puedo abrirla"
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Abriendo ${app.loadLabel(pm)}"
    }

    private fun findNumber(who: String): String? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 6) return digits
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val t = norm(who)
        val list = mutableListOf<Pair<String, String>>()
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) list.add(norm(c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return (list.firstOrNull { it.first == t } ?: list.firstOrNull { it.first.contains(t) })?.second
    }

    // ---------------- esfera sobre otras apps ----------------
    private fun showOrb() {
        if (orb != null) return
        if (!Settings.canDrawOverlays(this)) {
            if (!warnedOverlay) { warnedOverlay = true; say("Me falta el permiso para aparecer sobre otras aplicaciones. Actívelo en la aplicación.", false) }
            return
        }
        val d = resources.displayMetrics.density
        val s = (240 * d).toInt()
        val lp = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (80 * d).toInt() }
        try { orb = OrbView(this).also { wm.addView(it, lp) } }
        catch (e: Exception) { orb = null; Toast.makeText(this, "No pude mostrar la esfera: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun hideOrb() { orb?.let { try { wm.removeView(it) } catch (e: Exception) {} }; orb = null }

    private fun showCalibration(label: String) {
        if (!Settings.canDrawOverlays(this)) return
        val key = label.lowercase()
        val tv = TextView(this).apply {
            text = "Toque donde está el botón «$key»"; setTextColor(Color.WHITE); textSize = 20f
            gravity = Gravity.CENTER; setBackgroundColor(Color.argb(150, 0, 0, 0))
        }
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                prefs.edit().putString("pos_$key", "${e.rawX},${e.rawY}").apply()
                try { wm.removeView(tv) } catch (x: Exception) {}
                calib = null
                say("Guardado", false)
            }
            true
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        calib = tv
        wm.addView(tv, lp)
    }

    override fun onDestroy() {
        alive = false
        JarvisAccessibility.inst?.stopHold()
        h.removeCallbacksAndMessages(null)
        try { speech?.shutdown() } catch (e: Exception) {}
        try { model?.close() } catch (e: Exception) {}
        tts.shutdown()
        hideOrb()
        calib?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        try { wakeLock?.release() } catch (e: Exception) {}
        super.onDestroy()
    }
}
