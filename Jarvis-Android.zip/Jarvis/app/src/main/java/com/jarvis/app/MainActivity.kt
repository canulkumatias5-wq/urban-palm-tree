package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        l.addView(TextView(this).apply { text = "ATLAS"; textSize = 24f; setPadding(0, 0, 0, 20) })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, 24) }
        l.addView(status)
        btn("1. Dar permisos") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Permitir mostrar sobre otras apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Activar accesibilidad (busca Atlas)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        l.addView(TextView(this).apply { text = "\nClave de Gemini (para dudas y matemáticas, necesita internet):"; textSize = 15f })
        val keyBox = EditText(this).apply {
            hint = "Pega aquí tu clave"; isSingleLine = true
            setText(getSharedPreferences("jarvis", MODE_PRIVATE).getString("gemini_key", ""))
        }
        l.addView(keyBox)
        btn("Guardar clave") {
            getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("gemini_key", keyBox.text.toString().trim()).apply()
            Toast.makeText(this, "Clave guardada", Toast.LENGTH_SHORT).show(); refresh()
        }
        btn("4. Iniciar Atlas") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "Primero el paso 1", Toast.LENGTH_LONG).show()
            else { startForegroundService(Intent(this, JarvisService::class.java)); Toast.makeText(this, "Cargando voz, espera unos segundos…", Toast.LENGTH_LONG).show() }
        }
        btn("Detener Atlas") { stopService(Intent(this, JarvisService::class.java)); refresh() }
        l.addView(TextView(this).apply {
            text = "\nSi un permiso no se deja activar: Ajustes > Apps > Atlas > ⋮ > Permitir ajustes restringidos.\n" +
                "En Xiaomi también: Ajustes > Apps > Atlas > Otros permisos > Mostrar ventanas emergentes en segundo plano, y Batería > Sin restricciones."
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(l) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        fun m(ok: Boolean) = if (ok) "✅" else "❌"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val key = !getSharedPreferences("jarvis", MODE_PRIVATE).getString("gemini_key", "").isNullOrBlank()
        status.text = "${m(mic)} Micrófono\n${m(Settings.canDrawOverlays(this))} Aparecer sobre otras apps\n" +
            "${m(JarvisAccessibility.inst != null)} Accesibilidad\n${m(key)} Clave de Gemini\n${m(JarvisService.alive)} Atlas activo"
    }
}
