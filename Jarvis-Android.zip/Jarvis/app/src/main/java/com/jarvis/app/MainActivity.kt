package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        l.addView(TextView(this).apply {
            text = "JARVIS\n\nSigue los pasos en orden. Después di «Jarvis» o «ayúdame»."
            textSize = 18f; setPadding(0, 0, 0, 30)
        })
        btn("1. Dar permisos") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Permitir mostrar sobre otras apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Activar accesibilidad (busca Jarvis)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        l.addView(TextView(this).apply { text = "\nClave de Gemini (para responder dudas y matemáticas):"; textSize = 15f })
        val keyBox = EditText(this).apply {
            hint = "Pega aquí tu clave"; isSingleLine = true
            setText(getSharedPreferences("jarvis", MODE_PRIVATE).getString("gemini_key", ""))
        }
        l.addView(keyBox)
        btn("Guardar clave") {
            getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("gemini_key", keyBox.text.toString().trim()).apply()
            Toast.makeText(this, "Clave guardada", Toast.LENGTH_SHORT).show()
        }
        btn("4. Iniciar Jarvis") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "Primero el paso 1", Toast.LENGTH_LONG).show()
            else startForegroundService(Intent(this, JarvisService::class.java))
        }
        btn("Detener Jarvis") { stopService(Intent(this, JarvisService::class.java)) }
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
