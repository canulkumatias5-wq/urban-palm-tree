package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {
    companion object { @Volatile var inst: JarvisAccessibility? = null }

    private val h = Handler(Looper.getMainLooper())
    @Volatile private var holding = false

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; holding = false; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun go(path: Path, dur: Long, cb: GestureResultCallback? = null) {
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), cb, null)
    }

    /** dir: up = el dedo sube (siguiente video / bajar), down = el dedo baja, left, right */
    fun swipe(dir: String) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val hh = m.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "up" -> { p.moveTo(w / 2, hh * .75f); p.lineTo(w / 2, hh * .25f) }
            "down" -> { p.moveTo(w / 2, hh * .25f); p.lineTo(w / 2, hh * .75f) }
            "left" -> { p.moveTo(w * .8f, hh / 2); p.lineTo(w * .2f, hh / 2) }
            else -> { p.moveTo(w * .2f, hh / 2); p.lineTo(w * .8f, hh / 2) }
        }
        go(p, 220)
    }

    fun tap(x: Float, y: Float) = go(Path().apply { moveTo(x, y) }, 60)

    val isHolding: Boolean get() = holding
    private val autoStop = Runnable { holding = false }

    /** Mantiene pulsado como máximo 15 s (seguro). Se suelta con la voz o con una tecla de volumen. */
    fun startHold(x: Float, y: Float) {
        h.removeCallbacks(autoStop); holding = true; h.postDelayed(autoStop, 15000); step(x, y)
    }
    fun stopHold() { holding = false; h.removeCallbacks(autoStop) }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (holding && (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event.action == KeyEvent.ACTION_DOWN) stopHold()
            return true
        }
        return super.onKeyEvent(event)
    }

    private fun step(x: Float, y: Float) {
        if (!holding) return
        go(Path().apply { moveTo(x, y) }, 500, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { h.postDelayed({ step(x, y) }, 20) }
            override fun onCancelled(g: GestureDescription?) { h.postDelayed({ step(x, y) }, 100) }
        })
    }

    fun clickAny(vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return find(root, labels.map { it.lowercase() })
    }

    private fun find(n: AccessibilityNodeInfo, l: List<String>): Boolean {
        val d = n.contentDescription?.toString()?.lowercase()
        val t = n.text?.toString()?.lowercase()
        if ((d != null && d in l) || (t != null && t in l)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (find(c, l)) return true
        }
        return false
    }
}
