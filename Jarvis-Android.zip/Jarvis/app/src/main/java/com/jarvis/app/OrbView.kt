package com.jarvis.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class OrbView(ctx: Context) : View(ctx) {
    @Volatile var level = 0f
    @Volatile var speaking = false
    private var t = 0f
    private var amp = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pts = List(320) { Triple(Random.nextFloat() * 2 - 1, Random.nextFloat() * 6.283f, 0.92f + Random.nextFloat() * 0.12f) }

    override fun onDraw(c: Canvas) {
        t += 0.025f
        level *= 0.94f
        val target = if (speaking) 0.4f + 0.4f * abs(sin(t * 9f)) else max(level, 0.12f + 0.08f * sin(t * 3f))
        amp += (target - amp) * 0.25f
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) * 0.5f * (1f + 0.18f * amp)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.9f,
            intArrayOf(Color.argb(170, 0, 229, 255), Color.argb(50, 0, 150, 255), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.9f, p)
        p.shader = null
        p.color = Color.rgb(140, 245, 255)
        for ((u, a, k) in pts) {
            val s = sqrt(1 - u * u)
            val ang = a + t
            val x = s * cos(ang)
            val d = (s * sin(ang) + 1f) / 2f
            p.alpha = (70 + 185 * d).toInt()
            c.drawCircle(cx + x * r * k, cy + u * r * k, 1.5f + 2.5f * d, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.argb(200, 0, 229, 255)
        c.drawCircle(cx, cy, r * 1.15f, p)
        postInvalidateOnAnimation()
    }
}
