# Atlas para Android

Se compila en GitHub (la primera vez descarga el modelo de voz, tarda unos minutos más). La app pesa ~50 MB.

1. Abre Atlas y pulsa: 1 Permisos, 2 Mostrar sobre otras apps, 3 Accesibilidad (busca "Atlas"), pega tu clave de Gemini y "Guardar clave", 4 Iniciar Atlas.
2. La pantalla muestra ✅/❌ de cada permiso.
3. Di "Atlas" o "ayúdame". Se queda activo 25 s: puedes dar varias órdenes seguidas sin repetir el nombre. "Gracias" lo cierra.

Ejemplos: "desliza", "sube", "abre TikTok", "mándale mensaje a mamá por WhatsApp que diga hola", "llama a papá",
"dime la raíz cuadrada de 9" (necesita internet), "cambia de voz", "voz más grave", "configura botón adelante" / "aprieta adelante" / "para".

## Botones (juegos) — con seguridad
- "Atlas, configura botón adelante" y toca donde está. Después "presiónalo" o "presiona adelante" lo toca UNA vez.
- "Mantén adelante" lo mantiene pulsado (máximo 15 s). Se suelta con "suelta", "deja de presionar", "para" (sin decir Atlas) o pulsando una tecla de volumen.
- "Atlas, apágate" la deja en pausa (solo escucha "prende"). "Atlas, prende" la activa. "Detener Atlas" en la app la apaga del todo.
