# Jarvis para Android: cómo instalarlo

1. En el PC instala Android Studio (developer.android.com/studio).
2. Descomprime este ZIP. En Android Studio: File > Open > elige la carpeta "Jarvis". Espera a que termine el "Gradle sync".
3. En el móvil: Ajustes > Acerca del teléfono > toca 7 veces "Número de compilación". Luego Ajustes > Opciones de desarrollador > activa "Depuración USB".
4. Conecta el móvil por USB, acepta el aviso y pulsa el botón verde Run en Android Studio.
   (Alternativa: Build > Build APK(s), pasa el .apk al móvil y ábrelo.)
5. En la app Jarvis pulsa los botones 1, 2, 3 y 4 en orden.
   - Paso 3: busca "Jarvis" en Accesibilidad y actívalo.
   - Si Android dice "ajuste restringido": Ajustes > Apps > Jarvis > menú de tres puntos > Permitir ajustes restringidos, y repite el paso 3.
6. Quita el ahorro de batería para Jarvis (Ajustes > Batería > Jarvis > Sin restricciones), si no el sistema lo cierra.

## Ejemplos de órdenes (di antes "Jarvis" o "ayúdame")
- "Desliza" / "baja": siguiente vídeo de TikTok. "Sube": vídeo anterior.
- "Abre TikTok", "Abre WhatsApp".
- "Mándale mensaje a mamá por WhatsApp que diga hola" (el contacto debe llamarse como lo dices).
- "Llama a papá", "Busca recetas de paella", "Sube el volumen", "Atrás", "Inicio", "Captura de pantalla".
- Juegos: abre el juego y di "Jarvis, configura botón adelante", toca donde está el botón. Después: "Jarvis, aprieta adelante" y para detenerlo "Jarvis, para".
- "Jarvis, apágate" cierra el servicio.
